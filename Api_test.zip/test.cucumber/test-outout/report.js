$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/java/Features/taggedhooks2.feature");
formatter.feature({
  "line": 1,
  "name": "Test2 Tagged Hooks",
  "description": "",
  "id": "test2-tagged-hooks",
  "keyword": "Feature"
});
formatter.before({
  "duration": 14398526900,
  "status": "passed"
});
formatter.before({
  "duration": 196400,
  "status": "passed"
});
formatter.scenario({
  "line": 4,
  "name": "This is First test",
  "description": "",
  "id": "test2-tagged-hooks;this-is-first-test",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@First"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "this is the first step",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "this is the second step",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "this is the third step",
  "keyword": "Then "
});
formatter.match({
  "location": "TaggedHooksStepDefinition.this_is_the_first_step()"
});
formatter.result({
  "duration": 98445700,
  "status": "passed"
});
formatter.match({
  "location": "TaggedHooksStepDefinition.this_is_the_second_step()"
});
formatter.result({
  "duration": 1050700,
  "error_message": "java.lang.NullPointerException\r\n\tat stepDefinitions.TaggedHooksStepDefinition.this_is_the_second_step(TaggedHooksStepDefinition.java:183)\r\n\tat ✽.When this is the second step(src/test/java/Features/taggedhooks2.feature:6)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "TaggedHooksStepDefinition.this_is_the_third_step()"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "duration": 75500,
  "status": "passed"
});
formatter.after({
  "duration": 214793600,
  "status": "passed"
});
formatter.before({
  "duration": 6140400,
  "status": "passed"
});
formatter.before({
  "duration": 39400,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "This is Second test",
  "description": "",
  "id": "test2-tagged-hooks;this-is-second-test",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 9,
      "name": "@Second"
    }
  ]
});
formatter.step({
  "line": 11,
  "name": "this is the first step",
  "keyword": "Given "
});
formatter.step({
  "line": 12,
  "name": "this is the second step",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "this is the third step",
  "keyword": "Then "
});
formatter.match({
  "location": "TaggedHooksStepDefinition.this_is_the_first_step()"
});
formatter.result({
  "duration": 2731400,
  "status": "passed"
});
formatter.match({
  "location": "TaggedHooksStepDefinition.this_is_the_second_step()"
});
formatter.result({
  "duration": 708800,
  "error_message": "java.lang.NullPointerException\r\n\tat stepDefinitions.TaggedHooksStepDefinition.this_is_the_second_step(TaggedHooksStepDefinition.java:183)\r\n\tat ✽.When this is the second step(src/test/java/Features/taggedhooks2.feature:12)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "TaggedHooksStepDefinition.this_is_the_third_step()"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "duration": 66000,
  "status": "passed"
});
formatter.after({
  "duration": 107304600,
  "status": "passed"
});
formatter.before({
  "duration": 3933000,
  "status": "passed"
});
formatter.before({
  "duration": 57300,
  "status": "passed"
});
formatter.scenario({
  "line": 16,
  "name": "This is Third test",
  "description": "",
  "id": "test2-tagged-hooks;this-is-third-test",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 15,
      "name": "@Third"
    }
  ]
});
formatter.step({
  "line": 17,
  "name": "this is the first step",
  "keyword": "Given "
});
formatter.step({
  "line": 18,
  "name": "this is the second step",
  "keyword": "When "
});
formatter.step({
  "line": 19,
  "name": "this is the third step",
  "keyword": "Then "
});
formatter.match({
  "location": "TaggedHooksStepDefinition.this_is_the_first_step()"
});
formatter.result({
  "duration": 2759000,
  "status": "passed"
});
formatter.match({
  "location": "TaggedHooksStepDefinition.this_is_the_second_step()"
});
formatter.result({
  "duration": 1825700,
  "error_message": "java.lang.NullPointerException\r\n\tat stepDefinitions.TaggedHooksStepDefinition.this_is_the_second_step(TaggedHooksStepDefinition.java:183)\r\n\tat ✽.When this is the second step(src/test/java/Features/taggedhooks2.feature:18)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "TaggedHooksStepDefinition.this_is_the_third_step()"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "duration": 68900,
  "status": "passed"
});
formatter.after({
  "duration": 83073600,
  "status": "passed"
});
});