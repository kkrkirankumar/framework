package MyRunner;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import com.vimalselvam.cucumber.listener.Reporter;


import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;



	@RunWith(Cucumber.class)
	@CucumberOptions(
			features = {"src\\test\\java\\Features\\harphil1.feature"}, //the path of the feature files
			glue={"stepDefinitions"}, //the path of the step definition files
			plugin= {//"pretty",
					 "html:test-output", 
					 "json:json_output/cucumber.json", 
					 "junit:junit_xml/cucumber.xml",
					 "com.vimalselvam.cucumber.listener.ExtentCucumberFormatter:extent-reports/report.html"}, //to generate different types of reporting
			monochrome = true, //display the console output in a proper readable format
			strict = false, //it will check if any step is not defined in step definition file
			dryRun = false //to check the mapping is proper between feature file and step def file
			//tags = {"~@SmokeTest" , "~@RegressionTest", "~@End2End"}			
			)
	 
	public class TestRunner {
		
		@AfterClass
		public static void writeExtentReport() throws FileNotFoundException, IOException {
			ConfigFileReader configread = new ConfigFileReader();
			
			Reporter.loadXMLConfig(new File(""));
			
		}
	 
	}
	
	//ORed : tags = {"@SmokeTest , @RegressionTest"} -- execute all tests tagged as @SmokeTest OR @RegressionTest
	//ANDed : tags = tags = {"@SmokeTest" , "@RegressionTest"} -- execute all tests tagged as @SmokeTest AND @RegressionTest
	

