package MyRunner;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.junit.AfterClass;
import org.testng.annotations.BeforeSuite;

import com.vimalselvam.cucumber.listener.Reporter;

public class base {
	
	protected static String sServer;
	protected static String sToken;
	
	@BeforeSuite
	public void Credentials() throws IOException {
		Properties prop = new Properties();
		prop.load(getClass().getClassLoader().getResourceAsStream("config.properties"));
				
		base.sServer = prop.getProperty("server");		
		base.sToken = prop.getProperty("token");
		System.out.println("server: "+ base.sServer);
		System.out.println("token: "+ base.sToken);
		
		
	}
	
	@AfterClass
	public static void writeExtentReport() throws FileNotFoundException, IOException {
				
		Reporter.loadXMLConfig(new File("extent-config.xml"));
		
	}

}
