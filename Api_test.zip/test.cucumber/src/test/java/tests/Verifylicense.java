package tests;
import java.util.HashMap;
import common.utils;
import java.util.Map;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import MyRunner.base;
import cucumber.api.java.en.Given;
import io.cucumber.java.PendingException;
import io.cucumber.java.en.*;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import reports.ExtentReportListener;

public class Verifylicense extends base{
	
	String sProviderID = "d77c2329-7722-4ada-9c87-2a698e3ed198";
		
	@Test(priority=1)	
	public void licenseVerify_failed()  throws Throwable{
		
		
		RestAssured.baseURI = base.sServer;//"https://api.discovery-staging.verifiable.com";
		RequestSpecification req = RestAssured.given().accept("application/json").header("Content-Type", "application/json")
									.auth().oauth2(base.sToken);									
											  
		Response response = req.get("providers/"+sProviderID+"/licenses");
		
		utils.logAPIDetail(req, response);
	
		int statusCode = response.getStatusCode();		
		System.out.println("the status code is: "+ statusCode);		
		Assert.assertEquals(statusCode, 200);		
		System.out.println("the status line is: "+ response.getStatusLine());
		
		JsonPath jsonpath = response.jsonPath();
		String licenseName = jsonpath.get("find {it.licenseNumber=='2' }.licenseType.name").toString();
		System.out.println("license Name: "+ licenseName);
		Assert.assertEquals(licenseName, "NURSING BOARD");
		
		String sState = jsonpath.get("find {it.licenseNumber=='2' }.licenseType.source.state");
		System.out.println("State: "+ sState);
		Assert.assertEquals(sState, "IL");
		
		String sStatus = jsonpath.get("find {it.licenseNumber=='2' }.currentVerification.status");
		System.out.println("Status: "+ sStatus);
		Assert.assertEquals(sStatus, "Failed");
		
		System.out.println("Object: "+jsonpath.get("find {it.licenseNumber=='2' }").toString());
		
	}
	
	
	@Test(priority=2)
	public void licenseVerify_NotFound() throws Throwable {
		
		RestAssured.baseURI = base.sServer;
		RequestSpecification req = RestAssured.given().accept("application/json").header("Content-Type", "application/json")
									.auth().oauth2(base.sToken).log().all();
									
											  
		Response response = req.get("providers/"+sProviderID+"/licenses");	
		
		utils.logAPIDetail(req, response);
		
		int statusCode = response.getStatusCode();		
		System.out.println("the status code is: "+ statusCode);		
		Assert.assertEquals(statusCode, 200);		
		System.out.println("the status line is: "+ response.getStatusLine());
		
		JsonPath jsonpath = response.jsonPath();
		String licenseName = jsonpath.get("find {it.licenseNumber=='7' }.licenseType.name").toString();
		System.out.println("license Name: "+ licenseName);
		Assert.assertEquals(licenseName, "NURSING BOARD");
		
		String sState = jsonpath.get("find {it.licenseNumber=='7' }.licenseType.source.state");
		System.out.println("State: "+ sState);
		Assert.assertEquals(sState, "IL");
		
		String sStatus = jsonpath.get("find {it.licenseNumber=='7' }.currentVerification.status");
		System.out.println("Status: "+ sStatus);
		Assert.assertEquals(sStatus, "NotFound");
		
		System.out.println("Object: "+jsonpath.get("find {it.licenseNumber=='7' }").toString());
		
	}
	
	@Test(priority=3)
	public void licenseVerify_NeedsReview() throws Throwable{
		
		String sProviderID2 ="4ddcc575-20da-41ea-9999-b44f7342d16e";
		
		RestAssured.baseURI = base.sServer;
		RequestSpecification req = RestAssured.given().accept("application/json").header("Content-Type", "application/json")
									.auth().oauth2(base.sToken).log().all();
									
											  
		Response response = req.get("providers/"+sProviderID2+"/licenses");	
		
		utils.logAPIDetail(req, response);
		
		int statusCode = response.getStatusCode();		
		System.out.println("the status code is: "+ statusCode);		
		Assert.assertEquals(statusCode, 200);		
		System.out.println("the status line is: "+ response.getStatusLine());
		
		JsonPath jsonpath = response.jsonPath();
		String licenseName = jsonpath.get("find {it.licenseNumber=='5' }.licenseType.name").toString();
		System.out.println("license Name: "+ licenseName);
		Assert.assertEquals(licenseName, "Tennessee Department of Health");
		
		String sState = jsonpath.get("find {it.licenseNumber=='5' }.licenseType.source.state");
		System.out.println("State: "+ sState);
		Assert.assertEquals(sState, "TN");
		
		String sStatus = jsonpath.get("find {it.licenseNumber=='5' }.currentVerification.status");
		System.out.println("Status: "+ sStatus);
		Assert.assertEquals(sStatus, "NeedsReview");
		
		System.out.println("Object: "+jsonpath.get("find {it.licenseNumber=='5' }").toString());
		
		
	}
	


}
