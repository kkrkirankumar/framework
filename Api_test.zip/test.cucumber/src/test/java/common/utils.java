package common;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.StringWriter;

import org.apache.commons.io.output.WriterOutputStream;

import com.aventstack.extentreports.ExtentTest;

import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import reports.ExtentReportListener;


public class utils {
	static StringWriter requestWriter;
    static PrintStream requestCapture;
	
	public synchronized static void log(String sMessageTitle,String sDetail) {
		
		ExtentReportListener.test.get().info(sMessageTitle+": " + sDetail);
	}
	
	
	public synchronized static void logAPIDetail(RequestSpecification req,Response res) {
		
		//requestWriter = new StringWriter();
		ByteArrayOutputStream byteout = new ByteArrayOutputStream();
        requestCapture = new PrintStream(byteout);
        RestAssured.given().filter(new RequestLoggingFilter(requestCapture));
		
		ExtentTest currentTest = ExtentReportListener.test.get();
		currentTest.info("Request: " + byteout.toString());
		currentTest.info("Response Status Line: " + res.getStatusLine());		
		currentTest.info("Response Headers: " + res.getHeaders());
		currentTest.info("Response Cookies: " + res.getCookies());
		currentTest.info("Response Body: " + res.getBody().asString());
	}

}
